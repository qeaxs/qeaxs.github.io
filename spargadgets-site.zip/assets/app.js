
// Simple multilingual strings
const i18n = {
  de: {
    heroTitle: "Die besten günstigen Gadgets & Alltagshelfer",
    under30: "unter 30€",
    heroSub: "Entdecke nützliche Produkte für Haushalt, Fitness, Büro, Küche, Outdoor, DIY, Gadgets & Gaming – kuratiert, preiswert und übersichtlich.",
    affiliate: "Transparenz: Einige Links sind Affiliate-/Werbelinks. Als Amazon-Partner verdiene ich an qualifizierten Verkäufen.",
    ofWeek: "der Woche",
    dealsUnder10: "Deals unter 10€",
    allProducts: "Alle Produkte",
    noResults: "Keine Ergebnisse. Passe Filter oder Suche an.",
    legal: "Impressum & Datenschutz",
    legalTitle: "Impressum & Datenschutz (Vorlage)",
    legalBody: "Diese statische Seite verzichtet auf Cookies und externes Tracking. Affiliate-Links sind als Werbung gekennzeichnet. Trage hier deine rechtlichen Angaben ein (Pseudonym oder Firma, Kontakt-E-Mail). Prüfe die in deinem Land geltenden Pflichten.",
    operator: "Betreiber: Pseudonym / Firma",
    contact: "Kontakt: kontakt@spargadgets.example",
    affiliateShort: "*Werbelink – Als Amazon-Partner verdiene ich an qualifizierten Verkäufen.",
    toTop: "Nach oben ↑",
  },
  en: {
    heroTitle: "The best affordable gadgets & everyday helpers",
    under30: "under €30",
    heroSub: "Discover useful products for Home, Fitness, Office, Kitchen, Outdoor, DIY, Gadgets & Gaming – curated, affordable and cleanly organized.",
    affiliate: "Transparency: Some links are affiliate/advertising links. As an Amazon Associate I earn from qualifying purchases.",
    ofWeek: "of the week",
    dealsUnder10: "Deals under €10",
    allProducts: "All products",
    noResults: "No results. Adjust filters or search.",
    legal: "Imprint & Privacy",
    legalTitle: "Imprint & Privacy (Template)",
    legalBody: "This static site uses no cookies or external tracking. Affiliate links are labeled as advertising. Enter your legal details here. Check the obligations in your country.",
    operator: "Operator: Pseudonym / Company",
    contact: "Contact: contact@spargadgets.example",
    affiliateShort: "*Ad link – As an Amazon Associate I earn from qualifying purchases.",
    toTop: "Back to top ↑",
  }
};

const categories = ["Haushalt","Fitness","Büro/Homeoffice","Küche","Outdoor","DIY/Basteln","Gadgets","Gaming"];

let state = {
  lang: "de",
  allProducts: [],
  viewProducts: [],
};

const $ = (sel) => document.querySelector(sel);

function t(key){
  return i18n[state.lang][key] || key;
}

function applyI18n(){
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key = el.getAttribute("data-i18n");
    el.textContent = t(key);
  });
  // Price filter labels when EN
  const priceSel = $("#price");
  priceSel.options[0].textContent = state.lang === "de" ? "Preis: alle" : "Price: all";
  priceSel.options[1].textContent = state.lang === "de" ? "Deals unter 10€" : "Deals under €10";
  priceSel.options[2].textContent = state.lang === "de" ? "unter 20€" : "under €20";
  priceSel.options[3].textContent = state.lang === "de" ? "unter 30€" : "under €30";

  // Sort labels
  const sortSel = $("#sort");
  sortSel.options[0].textContent = state.lang === "de" ? "Sortieren: Bestseller" : "Sort: Bestsellers";
  sortSel.options[1].textContent = state.lang === "de" ? "Preis: aufsteigend" : "Price: low to high";
  sortSel.options[2].textContent = state.lang === "de" ? "Preis: absteigend" : "Price: high to low";
  sortSel.options[3].textContent = state.lang === "de" ? "Bewertung" : "Rating";
  sortSel.options[4].textContent = state.lang === "de" ? "Neuheiten" : "Newest";
}

function buildCategorySelect(){
  const select = $("#category");
  select.innerHTML = "";
  const allOpt = document.createElement("option");
  allOpt.value = "Alle";
  allOpt.textContent = state.lang === "de" ? "Kategorie: Alle" : "Category: All";
  select.appendChild(allOpt);
  categories.forEach(c=>{
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    select.appendChild(opt);
  });
}

function buildCategoryTabs(){
  const tabs = $("#categoryTabs");
  tabs.innerHTML = "";
  const all = document.createElement("span");
  all.className = "tag active";
  all.dataset.cat = "Alle";
  all.textContent = state.lang === "de" ? "Alle" : "All";
  tabs.appendChild(all);
  categories.forEach(c=>{
    const s = document.createElement("span");
    s.className = "tag";
    s.dataset.cat = c;
    s.textContent = c;
    tabs.appendChild(s);
  });
  tabs.addEventListener("click", (e)=>{
    const t = e.target.closest(".tag");
    if(!t) return;
    tabs.querySelectorAll(".tag").forEach(x=>x.classList.remove("active"));
    t.classList.add("active");
    $("#category").value = t.dataset.cat === "Alle" ? "Alle" : t.dataset.cat;
    render();
  });
}

function currency(v){
  return state.lang === "de" ? `${v.toFixed(2)} €` : `€${v.toFixed(2)}`;
}

function productCard(p){
  const wrap = document.createElement("div");
  wrap.className = "cardItem";
  wrap.innerHTML = `
    <img class="thumb" src="${p.image}" alt="${p.title}">
    <div class="body">
      <div class="title">${p.title}</div>
      <div class="rating">★ ${p.rating.toFixed(1)} · ${p.category}</div>
      <div class="badges">${p.top ? '<span class="badge top">Top 5</span>' : ''}${p.deal ? '<span class="badge deal">Deal</span>' : ''}</div>
      <div class="price">${currency(p.price)}</div>
      <a class="btn" href="${p.url}" target="_blank" rel="sponsored noopener nofollow">${state.lang === "de" ? "Jetzt kaufen *" : "Buy now *"}</a>
    </div>
  `;
  return wrap;
}

function render(){
  const q = $("#search").value.trim().toLowerCase();
  const catSel = $("#category").value;
  const priceSel = $("#price").value;
  const sortSel = $("#sort").value;

  let list = [...state.allProducts];

  if(catSel !== "Alle"){
    list = list.filter(p=>p.category === catSel);
  }
  if(q){
    list = list.filter(p=> (p.title + " " + (p.tags||"").join(" ")).toLowerCase().includes(q));
  }
  if(priceSel !== "all"){
    const lim = parseFloat(priceSel);
    list = list.filter(p=> p.price <= lim);
  }

  switch(sortSel){
    case "priceAsc": list.sort((a,b)=>a.price-b.price); break;
    case "priceDesc": list.sort((a,b)=>b.price-a.price); break;
    case "rating": list.sort((a,b)=>b.rating-a.rating); break;
    case "new": list.sort((a,b)=> new Date(b.added)-new Date(a.added)); break;
    default: list.sort((a,b)=> (b.bestseller|0) - (a.bestseller|0)); break;
  }

  const grid = $("#productGrid");
  grid.innerHTML = "";
  list.forEach(p=> grid.appendChild(productCard(p)));
  $("#emptyState").classList.toggle("hidden", list.length>0);
}

function renderTopAndDeals(){
  const topList = $("#topList");
  const dealsList = $("#dealsList");
  topList.innerHTML = "";
  dealsList.innerHTML = "";
  state.allProducts.filter(p=>p.top).slice(0,5).forEach(p=> topList.appendChild(productCard(p)));
  state.allProducts.filter(p=>p.deal && p.price<=10).slice(0,8).forEach(p=> dealsList.appendChild(productCard(p)));
}

async function loadProducts(){
  const file = state.lang === "de" ? "data/products.de.json" : "data/products.en.json";
  const res = await fetch(file);
  const data = await res.json();
  state.allProducts = data.products;
  applyI18n();
  buildCategorySelect();
  buildCategoryTabs();
  buildQuickChips();
  renderTopAndDeals();
  render();
}

function buildQuickChips(){
  const wrap = document.getElementById("quickChips");
  wrap.innerHTML = "";
  const chips = [
    {k:"Deals <10€", f:()=>{$("#price").value="10"; render();}},
    {k:"Neuheiten", f:()=>{$("#sort").value="new"; render();}},
    {k:"Bestseller", f:()=>{$("#sort").value="bestseller"; render();}},
    {k:"Gaming", f:()=>{$("#category").value="Gaming"; render();}},
  ];
  chips.forEach(c=>{
    const el = document.createElement("span");
    el.className = "chip";
    el.textContent = state.lang === "de" ? c.k : ({
      "Deals <10€":"Deals <€10",
      "Neuheiten":"Newest",
      "Bestseller":"Bestsellers",
      "Gaming":"Gaming"
    }[c.k]);
    el.addEventListener("click", c.f);
    wrap.appendChild(el);
  });
}

function setLang(newLang){
  if(state.lang === newLang) return;
  state.lang = newLang;
  document.getElementById("lang-de").classList.toggle("active", newLang==="de");
  document.getElementById("lang-en").classList.toggle("active", newLang==="en");
  loadProducts();
  applyI18n();
}

function initEvents(){
  $("#search").addEventListener("input", render);
  $("#category").addEventListener("change", render);
  $("#sort").addEventListener("change", render);
  $("#price").addEventListener("change", render);
  $("#lang-de").addEventListener("click", ()=>setLang("de"));
  $("#lang-en").addEventListener("click", ()=>setLang("en"));
  $("#openLegal").addEventListener("click",(e)=>{e.preventDefault(); document.getElementById("legalDialog").showModal();});
  $("#toTop").addEventListener("click",(e)=>{e.preventDefault(); window.scrollTo({top:0,behavior:'smooth'});});
}

document.addEventListener("DOMContentLoaded", ()=>{
  initEvents();
  loadProducts();
});
